import java.util.Scanner;
public class MainCarro {
    public static void main(String[] args) {
        Carro carro1 = new Carro();
        Scanner scan = new Scanner(System.in);

    System.out.println("Digite a cor:");
    String cor = scan.nextLine();
    carro1.cor = cor;

        System.out.println("Digite o ano:");
        int ano = scan.nextInt();
        carro1.ano = ano;


        System.out.println("Digite o modelo:");;
        String modelo = scan.nextLine();
        carro1.modelo = modelo;
        
        System.out.println("Digite a potencia:");
        int potencia = scan.nextInt();
        carro1.potencia = potencia;

        System.out.println("Digite a cilindrada:");
        int cilindrada = scan.nextInt();
        carro1.cilindrada = cilindrada;

        System.out.println("Digite a velocidade:");
        int velocidade = scan.nextInt();
        carro1.velocidade = velocidade;

        carro1.ligar();

}

}

