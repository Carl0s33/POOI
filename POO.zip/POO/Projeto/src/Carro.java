public class Carro {

    // características do carro

    String modelo;
    String cor;
    boolean ligado;
    int ano;
    int velocidade;
    int potencia;
    int cilindrada;

    void pintar(String cor) {
        this.cor = cor;
        System.out.println("Carro pintado de " + cor);
    }

    // acoes do carro
    void ligar() {
       this.ligado = true;
        System.out.println("Carro ligado.");
    }

    void desligar() {
        this.ligado = false;
        System.out.println("Carro desligado.");
    }
    
    void acelerar(int velocidade) {
        this.velocidade += velocidade;
        System.out.println("Velocidade do carro: " + this.velocidade + " km/h");
    }
    
    void freiar(int velocidade) {
        this.velocidade -= velocidade;
        System.out.println("Velocidade do carro: " + this.velocidade + " km/h");
    }
    
    void trocarCor(String cor) {
        this.cor = cor;
        System.out.println("Cor do carro alterada para: " + this.cor);
    }
    
    void mostrarInformacoes() {
        System.out.println("Modelo: " + this.modelo);
        System.out.println("Cor: " + this.cor);
        System.out.println("Ligado: " + this.ligado);
        System.out.println("Ano: " + this.ano);
        System.out.println("Velocidade: " + this.velocidade + " km/h");
        System.out.println("Potência: " + this.potencia + " cv");
        System.out.println("Cilindrada: " + this.cilindrada + " cc");
    }
}

    