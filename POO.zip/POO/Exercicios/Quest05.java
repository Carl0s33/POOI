public class Quest05 {
        public static void main(String[] args) {
            for (int i = 100; i <= 1000; i++) {
                if (i % 7 == 0) {
                    System.out.println(i);
                }
            }
        }
    }
    

