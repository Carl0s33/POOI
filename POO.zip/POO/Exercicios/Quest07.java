public class Quest07 {
    public static void main(String[] args) {
        int contador = 0;
        for (int i = 1; i <= 1000; i++) {
            if (1000 % i == 0) {
                contador++;
            }
        }
        System.out.println("O número 1000 possui " + contador + " divisores.");
    }
}
