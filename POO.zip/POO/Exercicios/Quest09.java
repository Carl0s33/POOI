public class Quest09 {
    public static void main(String[] args) {
        int[] valores = new int[20];
        int maior = Integer.MIN_VALUE;
        int menor = Integer.MAX_VALUE;

        for (int i = 0; i < 20; i++) {
            valores[i] = (int) (Math.random() * 100); // Gera valores aleatórios entre 0 e 99
            System.out.println("Valor " + (i + 1) + ": " + valores[i]);

            if (valores[i] > maior) {
                maior = valores[i];
            }
            if (valores[i] < menor) {
                menor = valores[i];
            }
        }

        System.out.println("Maior valor: " + maior);
        System.out.println("Menor valor: " + menor);
    }

}
