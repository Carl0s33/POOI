import java.util.Scanner;
public class Quest04 {
    public static void main(String[] args) {
        int n = 0;
        int soma = 0;
        double media = 0;
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite números (digite 0 para sair):");

        while (n != 0) {
            n = scanner.nextInt();
            soma += n;
        }

        media = (double) soma / (n - 1);

        System.out.println("A média aritmética dos números digitados é: " + media);
    }