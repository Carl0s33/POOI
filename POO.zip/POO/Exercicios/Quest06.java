public class Quest06 {
    public static void main(String[] args) {
        int soma = 0;
        int contador = 0;
        for (int i = 1000; i <= 2000; i++) {
            if (i % 3 == 0 && i % 5 == 0 && i % 10 != 0) {
                System.out.println(i);
                soma += i;
                contador++;
            }
        }
        if (contador > 0) {
            double media = (double) soma / contador;
            System.out.println("A média dos valores é: " + media);
        } else {
            System.out.println("Não existem valores entre 1000 e 2000 que são divisíveis por 3 e por 5 mas não são divisíveis por 10.");
        }
    }
}
